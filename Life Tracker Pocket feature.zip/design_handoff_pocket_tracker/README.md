# Handoff: Pocket Tracker (Life Tracker feature)

## Overview
**Pocket Tracker** is a new feature for the existing **Life Tracker** app (habit + task tracker). It lets a user set a **monthly income/budget** and then log **expenses** against it. It has a top tab bar with five tabs:

- **Overview** — income vs spent vs remaining, category breakdown, recent transactions
- **Calendar** — per-day spend for a month; tap a day to see that day's expenses
- **Stats** — weekly bars, 6-month trend, this-vs-last-month comparison, top categories
- **Goals** — saving goals (e.g. a certification, a car) with progress + a suggested monthly saving
- **Settings** — edit income, recurring payday, per-month budget overrides, and a dashboard-style chooser

It is **purely financial** — it does NOT tie into Life Tracker's XP/level/streak gamification.

## About the design files
The files in this bundle (`Pocket Tracker.dc.html` + `support.js`) are a **design reference created in HTML** — a prototype showing the intended look, layout, and behavior. **It is not production code to copy.** Your task is to **recreate these designs inside the Life Tracker codebase** using its existing framework, component library, state management, and conventions. If the repo has no established UI environment yet, choose the most appropriate framework for it and implement there.

Open `Pocket Tracker.dc.html` in a browser to view it (keep `support.js` next to it). It's laid out as a **design board** (canvas) with two "turns":
- **Turn 1** — three Overview dashboard directions (`1a` Budget Ring, `1b` Ledger Flow, `1c` Stat Cards + Donut), plus the flow screens (Set income, Add expense, History) and a light-theme showcase.
- **Turn 2** (top of the board) — the new tabs: Calendar (`2a`/`2b`), Stats (`2c`/`2d`), Goals (`2e`/`2f`), Settings (`2g`), and a light-theme parity strip.

Each option has a small badge (`1a`, `2c`, …) in its corner. Every screen is shown in **dark theme** (primary) and **light theme**, on **web** and **mobile**.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and layout are final and should be recreated faithfully using the codebase's own components/tokens. The exact hex values, fonts, and measurements are listed below. Data shown (amounts, dates, merchants) is **sample data** — wire it to real state.

## Design decisions still open (confirm with product owner)
The prototype shows **all variations** on purpose. Before building, pick one per tab (the Settings "dashboard style" chooser is designed to let the *end user* switch between the three Overview styles at runtime — `1a`/`1b`/`1c` — so all three Overview layouts may be worth building; Calendar/Stats/Goals each need only one chosen variation).

---

## Design tokens

### Fonts (Google Fonts)
- **Display / headings / all numbers:** `Chakra Petch` — weights 500, 600, 700. Used for the wordmark, section titles, and every numeric value (amounts, %, counts). Letter-spacing 1–3px on the wordmark/labels.
- **Body / labels / UI text:** `JetBrains Mono` — weights 400, 500, 600, 700. This is the default `body` font. The whole app is monospace.

### Dark theme (primary)
| Token | Value | Use |
|---|---|---|
| App background | `#190a30` | page behind cards |
| Nav / sidebar / bottom-bar | `#0e0620` | left sidebar (web), bottom tab bar (mobile) |
| Card | `#1e0f3a` | all panels/cards |
| Inner / input / chip / icon-tile | `#24123f` | fields, chips, avatars |
| Card border | `rgba(255,90,160,0.16)` (18% on outer frames) | 1px borders |
| Divider | `rgba(255,255,255,0.05)` | list row separators |
| Track (progress/bar bg) | `rgba(255,255,255,0.06)` | unfilled bar |
| Muted bar (inactive) | `#4b3a6b` | greyed chart bars |
| Text primary | `#f2e9ff` | headings, values |
| Text secondary | `#cdb9e8` | chip labels |
| Text muted | `#9d86c4` | sublabels, units |
| Text faint | `#7c6aa0` / `#6b5a8c` | tiny labels, inactive icons |
| Accent pink | `#ff3d84` (wordmark) / `#ff2d78` (active) | brand, active states |
| Link / link-hover | `#ff6ec7` / `#ff9bd8` | links, "View all" |
| Cyan | `#22d3ee` | USD amounts, remaining, accents |
| Income / positive | `#34e5a3` | income, gains |
| Expense / negative | `#ff5470` | expense amounts, losses |
| **Accent gradient** | `linear-gradient(135deg, #ff2d78, #b429f9)` | primary buttons, active tab, wordmark tile |
| **Progress gradient** | `linear-gradient(90deg, #ff2d78, #22d3ee)` | XP-style progress fills |

### Light theme
| Token | Value |
|---|---|
| App background | `#eef2f8` |
| Nav / card | `#ffffff` |
| Inner / track | `#f1f5fb` / `#eef2f8` |
| Border | `#dbe3ee` (cells `#e6ecf5`) |
| Text primary | `#1e293b` |
| Text muted | `#64748b` / `#94a3b8` |
| Accent blue | `#2563eb` (wordmark, active, links) |
| Income / positive | `#16a34a` |
| Expense / negative | `#e11d48` |
| Remaining / cyan | `#0891b2` |
| **Accent gradient** | `linear-gradient(135deg, #2563eb, #16c47f)` |

### Category palette (used in donut, bars, legends)
Dark theme values (light-theme swaps in brighter equivalents shown in parentheses where relevant):
`food #ff6b6b (#ef4444)`, `grocery #4ade80 (#22c55e)`, `clothing #c084fc`, `travel #38bdf8`, `rent #fb923c`, `loan #f472b6`, `education #facc15 (#eab308)`, `medical #2dd4bf (#14b8a6)`, `entertainment #a78bfa (#8b5cf6)`, `AI #22d3ee`, `business #60a5fa`, `transport #fbbf24 (#f59e0b)`, `family #f9a8d4`, `gift #f87171 (#f43f5e)`, `coffee #d6a06a`, `subscriptions #818cf8`, `utilities #34d399`, `fuel #fb7185`, `savings #10b981`, `other #94a3b8`.

### Radius / shadow / geometry
- Card radius **14–16px**; inner/input **11–12px**; chips/buttons **8–10px**; small pills/badges **6px**.
- Card shadow (dark): `0 24px 60px rgba(0,0,0,0.5)`; (light): `0 24px 60px rgba(30,41,59,0.18)`.
- Web left sidebar width **60px**; sidebar icon-tile 34–38px.
- Mobile frame: width ~**390px** content, bezel border **9px**, corner radius **38px**, bottom tab bar height **56px**.
- Selected/emphasis ring: `border:1px solid <accent>` + `box-shadow: 0 0 0 2px rgba(<accent>,0.2)`.

### Icons
Sidebar/nav use simple glyphs in the prototype (`▦ ◎ ▥ 👛`) — **replace with the icon set already used in Life Tracker** (the app uses lucide-style line icons). Category icons are emoji (🛒 🍔 🏠 🚕 ☕ 🤖 📚 💊 🎁 …); keep emoji or swap for the app's icon set. Nav tab order maps to: Overview `▦`, Calendar `📅`, Stats `📊`, Goals `🎯`, Settings `⚙️` / `👛` wallet.

### Currency
Two currencies: **IQD** (primary) and **USD** (secondary). All amounts show IQD with thousands separators (`1,235,000 IQD`) and an approximate USD underneath/next to it (`≈ $943`). Compact forms `K`/`M` are used in tight cells (`1.24M`, `765K`). Prototype uses an approximate rate of **~1,310 IQD = $1**; make the rate configurable.

---

## Screens / views

### Tab bar (all tabs)
Horizontal pill bar: `Overview · Calendar · Stats · Goals · Settings`. Inactive = muted text, transparent; active = accent gradient fill, white text, radius 8px. On mobile this becomes a **bottom tab bar** (icons only). Above it sits the **POCKET TRACKER** wordmark (Chakra Petch 700, letter-spacing 2px, accent color) and the breadcrumb `LIFE TRACKER · MONTHLY BUDGET`.

### 1 · Overview (three selectable styles)
Month selector top-right (`‹ Jun / July 2026 / Aug ›`). All three show the same core numbers: **Income 2,000,000**, **Spent 1,235,000 (62%)**, **Remaining 765,000**, days-left / safe-to-spend.
- **1a Budget Ring** — large ring gauge (conic-gradient: accent for % spent, track for rest; hole shows remaining). Beside it: income/spent mini-stats + "safe to spend/day". Below: category breakdown as horizontal progress bars (2-col). Right rail: Recent list.
- **1b Ledger Flow** — full-width segmented budget bar (each category a colored segment + remaining track), legend (Spent / Remaining). Main: transaction **ledger grouped by day**. Right rail: Income/Spent/Remaining stat tiles.
- **1c Stat Cards + Donut** — row of 4 KPI cards (Income, Spent, Remaining, Saved %). Below: donut (conic-gradient category segments) + legend, and a transactions table (Merchant / Category / Amount).

### 2 · Calendar
Header: month nav + **month total** + **daily average**.
- **2a Heat grid** — 7-col month grid; each day cell shows the date and that day's total (compact `K`); cell background tint scales with spend intensity (`rgba(accent, alpha)` — alpha ≈ 0.02 none → 0.5 highest). Selected day has the emphasis ring. Right panel lists the selected day's expenses + day total + count.
- **2b Agenda + mini-month** — left: compact mini-month (spend days tinted, selected day filled) + month total card; right: **agenda** — day sections (date + day total) with expense rows.
- Tapping a day selects it and shows its expenses. Month nav switches months.

### 3 · Stats
- **2c Chart grid** — 2×2: **Weekly spend bars** (W1–W5, vertical, amount labels; inactive/future weeks greyed `#4b3a6b`); **6-month trend** (line + area, dots; latest/low point highlighted cyan/green); **Jul vs Jun** (per-category paired bars — last month grey `#6b5a8c`, this month accent — with +/-% delta); **Top categories** (horizontal ranked bars, category colors).
- **2d Single focus** — one large trend chart with a **Week / Month / 6M** segmented toggle and summary stats (avg/mo, high, low); below, two panels: Top categories + Jul-vs-Jun delta list.
- Charts are simple SVG (polyline + area) and CSS-height bars — recreate with the codebase's chart lib (Recharts/Chart.js/etc.).

### 4 · Goals
Each goal: icon tile, name, **saved / target**, progress bar (per-goal gradient), **% complete** badge, **deadline + months left**, and a **suggested monthly saving** = `ceil((target − saved) / monthsLeft)`, plus **+ Add funds**.
- **2e Goal cards** — summary header (total saved / total target across goals, overall %), then a row of goal cards + a dashed "New goal" tile.
- **2f Goal rings** — list rows, each with a circular progress ring (conic-gradient at goal %), name, saved/target + USD, suggested monthly + ETA, % + months left. "+ New goal" button.
- Sample goals: **HTB Certification** 300,000 / 500,000 (60%, by Nov 2026, 50,000/mo); **Car** 4,500,000 / 20,000,000 (23%, by Dec 2027, 861,000/mo); **Side project** 650,000 / 1,000,000 (65%, by Oct 2026, 117,000/mo).

### 5 · Settings
- **Monthly income** — value + currency-default toggle (IQD/USD) + Edit.
- **Recurring payday** — toggle + a **day picker (1–31, default 25)**; when on, the budget period auto-resets on that day each month. Shows "Next reset: Jul 25 → starts August budget".
- **Budget overrides** — set a different budget for a specific month (list of overrides, e.g. `August 2026 · 2,500,000`, `June 2026 · 1,800,000`) + Add.
- **Dashboard style** — three selectable preview cards (Budget Ring `1a` / Ledger Flow `1b` / Stat Cards `1c`); the selected one determines which Overview layout renders. Selection should persist.

### Flow screens (shared, from Turn 1)
- **Set monthly income** — amount field, IQD/USD toggle (with live USD conversion), income source (Salary…), "Repeat every month" toggle, "Start tracking" CTA.
- **Add expense** — big amount field (+ USD conversion), **category chip grid** (full category set below), note field, date, Cancel / Save. Mobile is a bottom-sheet with a large amount display.
- **Expense history** — month + category filters + search; summary tiles (Total spent / Entries / Avg per day); rows **grouped by day** with per-day totals, category, payment method, IQD + USD.

---

## Interactions & behavior
- **Month navigation** everywhere; the active month drives all figures.
- **Budget for a month** = `overrides[month] ?? income.amount`.
- **Recurring payday**: when enabled with `resetDay = d`, a budget "month" runs from day `d` to day `d` of the next calendar month; the month label/figures follow that period.
- **Add expense**: appends to expenses, immediately updates spent/remaining, category breakdown, calendar cell, stats.
- **Calendar day select**: filters the detail panel/agenda to that date.
- **Stats period toggle** (2d): recompute the chart for Week/Month/6M.
- **Goal "Add funds"**: increases `saved`, recomputes % and suggested monthly.
- **Dashboard style chooser**: switches the Overview layout; persist the choice.
- **Currency toggle**: flips which currency is primary; the other shows as `≈` secondary.
- Transitions are subtle (fades/slides ~150–200ms). Buttons/tabs have hover + active states (accent gradient on active).

## State management
Suggested shape (adapt to the codebase's store):
```
income: { amount, currency: 'IQD'|'USD', source, recurring: bool, resetDay: 1..31, overrides: { 'YYYY-MM': amount } }
expenses: [ { id, amount, currency, categoryId, note, date: 'YYYY-MM-DD', paymentMethod } ]
categories: [ { id, label, icon, color } ]   // seed list below
goals: [ { id, name, icon, target, saved, deadline: 'YYYY-MM' } ]
ui: { activeMonth: 'YYYY-MM', selectedDate, dashboardStyle: 'ring'|'ledger'|'cards', primaryCurrency, statsPeriod }
```
Derived selectors: `budget(month)`, `spent(month)`, `remaining`, `spentPct`, `dailyAvg`, `safeToSpendPerDay`, `categoryBreakdown(month)`, `weeklyBuckets(month)`, `monthlyTotals(last6)`, `daySpend(date)`, `suggestedMonthly(goal)`, USD/IQD conversion.

## Seed categories (income defaults + additions)
food, grocery, clothing, travel, rent, loan, education, medical, entertainment, AI, business, transport, family, gift, other — **plus** coffee, subscriptions, utilities, fuel, health, insurance, savings, pets, charity. (Each with an emoji/icon + a palette color from the token list.)

## Design tokens summary → map these to the codebase's existing tokens where they exist; only add new ones for the pink/purple financial accents and the IQD/USD formatting.

## Assets
No external image assets. Fonts: Chakra Petch + JetBrains Mono (Google Fonts). Icons: emoji in the prototype — use Life Tracker's existing icon library. Charts: rebuild with the app's charting approach (prototype uses inline SVG/CSS).

## Files in this bundle
- `Pocket Tracker.dc.html` — the full design board (open in a browser; keep `support.js` beside it). Search the file for badge ids (`1a`, `2c`, etc.) or the comment markers (`OPTION 1a`, `CALENDAR`, `STATS`, `GOALS`, `SETTINGS`, `LIGHT PARITY`) to jump to a screen's exact markup and copy precise values.
- `support.js` — runtime needed only to view the HTML prototype. **Not part of the feature** — do not ship it.
- `PROMPT.md` — a ready-to-paste prompt for Claude Code.
