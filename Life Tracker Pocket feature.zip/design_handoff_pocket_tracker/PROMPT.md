# Paste this into Claude Code

I'm adding a new feature called **Pocket Tracker** to my existing **Life Tracker** app (a habit + task tracker I built and published on GitHub). Pocket Tracker is a personal **income & expense tracker**: I set a monthly income/budget, then log expenses against it and watch what's left.

## Your task
Implement Pocket Tracker **in this codebase**, using the project's existing framework, component library, styling system, state management, and conventions. The design is provided as an **HTML prototype** in the `design_handoff_pocket_tracker/` folder — it shows the intended look and behavior at **high fidelity**, but it is a **reference, not code to copy**. Recreate it natively in this app.

**Before writing code:**
1. Read `design_handoff_pocket_tracker/README.md` in full — it has exact colors, fonts, spacing, every screen, interactions, and the suggested state shape.
2. Open `design_handoff_pocket_tracker/Pocket Tracker.dc.html` in a browser (keep `support.js` next to it) to see the real thing. It's a design board with badges (`1a`, `2c`, …) on each option; search the file for a badge id or the comment markers (`CALENDAR`, `STATS`, `GOALS`, `SETTINGS`) to find the exact markup and pull precise values.
3. Explore my codebase and **match its patterns** — reuse existing components (buttons, cards, inputs, modals, icons), design tokens, routing, and store. Do not introduce a parallel styling system. My app is monospace/pixel themed with a dark (purple/magenta) and light (blue) theme — Pocket Tracker must support both themes exactly like the rest of the app.

## Scope
A new **Pocket Tracker** section with a top tab bar: **Overview · Calendar · Stats · Goals · Settings** (bottom tab bar on mobile). It must be fully responsive (web + mobile) and **purely financial — do NOT hook it into the XP / level / streak / badge gamification.**

- **Overview** — income vs spent vs remaining, category breakdown, recent transactions. Build the **three layouts** (Budget Ring `1a`, Ledger Flow `1b`, Stat Cards + Donut `1c`); which one renders is chosen in Settings and persisted.
- **Calendar** — month grid with per-day spend; tap a day → that day's expenses; month total + daily average; month navigation. (Prototype shows two takes, `2a` heat-grid and `2b` agenda — build `2a` unless you think `2b` fits better; ask me.)
- **Stats** — weekly spend bars, 6-month trend line, this-month-vs-last-month category comparison, top categories ranked. Use whatever charting the app already uses.
- **Goals** — saving goals with icon, saved/target, progress, deadline, and a **suggested monthly amount** = `ceil((target − saved) / monthsLeft)`, plus add-funds. Seed with my examples (HTB certification, car, side project — see README).
- **Settings** — edit monthly income, IQD/USD default, **recurring payday** (auto-reset budget on a chosen day each month, default the 25th), **per-month budget overrides**, and the **dashboard-style chooser**.
- **Flows** — set monthly income, add expense (amount + category grid + note + date), expense history (filters + grouped by day).

## Key rules
- **Dual currency IQD + USD** everywhere: IQD primary with a configurable rate (~1,310 IQD/$1), USD shown as `≈ $…`.
- **Categories** (seed): food, grocery, clothing, travel, rent, loan, education, medical, entertainment, AI, business, transport, family, gift, other, coffee, subscriptions, utilities, fuel, health, insurance, savings, pets, charity — each with an icon + color (see README palette). Make categories user-manageable.
- Persist data with whatever this app uses (localStorage / DB / API). Match the existing data layer.
- Keep amounts, dates, merchants from the prototype as **sample/seed data**, not hard-coded UI.

## How to work
- Start by proposing a short **implementation plan**: where files go, which existing components you'll reuse, the state/model, and the routing. Wait for my OK before building.
- Then implement tab by tab, keeping each PR/commit focused.
- Flag anything in the design that conflicts with existing patterns and ask instead of guessing.

The design files are in `design_handoff_pocket_tracker/`. Start with the README.
